/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'sk', {
	pathName: 'media objekt',
	title: 'Media Embed',
	button: 'Vložte Media Embed',
	unsupportedUrlGiven: 'Zadaná URL nie je podporovaná.',
	unsupportedUrl: 'URL {url} nie je podporovaná Media Embedom.',
	fetchingFailedGiven: 'Nepodarilo sa získať obsah zo zadanej URL.',
	fetchingFailed: 'Nepodarilo sa získať obsah z {url}.',
	fetchingOne: 'Získavanie oEmbed odpovede...',
	fetchingMany: 'Získavanie oEmbed odpovede, {current} z {max} hotových...'
} );
